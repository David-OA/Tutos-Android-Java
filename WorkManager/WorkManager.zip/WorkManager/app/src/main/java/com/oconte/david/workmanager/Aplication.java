package com.oconte.david.workmanager;

import android.app.Application;

import java.util.concurrent.TimeUnit;

import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

public class Aplication extends Application {

    @Override
    public void onCreate() {

        super.onCreate();

        final PeriodicWorkRequest periodicWorkRequest = new PeriodicWorkRequest.Builder(MyWorker.class, 1, TimeUnit.MINUTES)
                .addTag("periodic_work")
                .build();

        WorkManager.getInstance().enqueue(periodicWorkRequest);
    }
}
